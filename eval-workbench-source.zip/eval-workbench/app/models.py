from typing import Annotated, Literal

from pydantic import BaseModel, ConfigDict, Field, StringConstraints, model_validator

Text = Annotated[str, StringConstraints(strip_whitespace=True, min_length=1, max_length=20000)]
Name = Annotated[str, StringConstraints(strip_whitespace=True, min_length=1, max_length=100)]
Score = Annotated[int, Field(strict=True, ge=1, le=5)]
ErrorType = Literal['无', '事实错误', '推理错误', '未遵循指令', '遗漏要点', '表达不清', '无依据断言', '过度拒答']

RUBRIC = {
    'version': '1.0',
    'dimensions': [
        {'key':'correctness','name':'正确性','weight':0.4,'description':'结论、事实、计算与参考要点一致。'},
        {'key':'instruction','name':'遵循指令','weight':0.3,'description':'遵守任务范围、格式与限制。'},
        {'key':'completeness','name':'完整性','weight':0.2,'description':'覆盖必要要点，不遗漏关键条件。'},
        {'key':'clarity','name':'表达清晰','weight':0.1,'description':'语言清楚，组织合理，无歧义。'},
    ],
    'anchors': {'1':'根本不满足，存在严重问题','2':'较差，需要大幅修改','3':'基本可用，仍有明显不足','4':'良好，只有轻微不足','5':'完全满足，无实质问题'},
    'error_types': ['无','事实错误','推理错误','未遵循指令','遗漏要点','表达不清','无依据断言','过度拒答'],
}


class Input(BaseModel):
    model_config = ConfigDict(extra='forbid')


class TaskIn(Input):
    prompt: Text
    reference: str = Field(default='', max_length=20000)
    category: Name = '综合'
    provenance: Literal['demo','model','human'] = 'demo'


class AnswerIn(Input):
    model: Name
    text: Text
    source: Literal['synthetic_demo','model_output','human_written']


class Scores(Input):
    correctness: Score
    instruction: Score
    completeness: Score
    clarity: Score


class AnnotationData(Input):
    scores: Scores
    rationale: Text
    error_types: list[ErrorType] = Field(min_length=1,max_length=8)
    annotator: Name
    annotation_source: Literal['human','ai_assisted'] = 'human'

    @model_validator(mode='after')
    def coherent_errors(self):
        if len(set(self.error_types)) != len(self.error_types):
            raise ValueError('错误类型不能重复')
        if '无' in self.error_types and len(self.error_types) > 1:
            raise ValueError('“无”不能与其他错误类型同时选择')
        return self


class AnnotationIn(AnnotationData):
    expected_version: int = Field(ge=0,strict=True)


class ReviewIn(Input):
    decision: Literal['approved','needs_revision']
    reviewer: Name
    note: Text
    expected_version: int = Field(ge=0,strict=True)


class AnswerImport(AnswerIn):
    annotation: AnnotationData | None = None


class TaskImport(TaskIn):
    answers: list[AnswerImport] = Field(default_factory=list,max_length=50)


class ImportIn(Input):
    schema_version: Literal[1]
    tasks: list[TaskImport] = Field(min_length=1,max_length=500)


class FeedbackIn(Input):
    content: Text
    reporter: Name


class FeedbackUpdate(Input):
    status: Literal['open','resolved']
    resolution: str = Field(default='',max_length=20000)

    @model_validator(mode='after')
    def resolved_needs_note(self):
        if self.status == 'resolved' and not self.resolution.strip():
            raise ValueError('处理完成时需要填写处理说明')
        return self
