// Standalone browser demonstration. The Python API remains the reference implementation.
export const rubric={version:'1.0',dimensions:[
 {key:'correctness',name:'正确性',weight:.4,description:'结论、事实、计算与参考要点一致。'},
 {key:'instruction',name:'遵循指令',weight:.3,description:'遵守任务范围、格式与限制。'},
 {key:'completeness',name:'完整性',weight:.2,description:'覆盖必要要点，不遗漏关键条件。'},
 {key:'clarity',name:'表达清晰',weight:.1,description:'语言清楚，组织合理，无歧义。'}],
 anchors:{1:'根本不满足，存在严重问题',2:'较差，需要大幅修改',3:'基本可用，仍有明显不足',4:'良好，只有轻微不足',5:'完全满足，无实质问题'},
 error_types:['无','事实错误','推理错误','未遵循指令','遗漏要点','表达不清','无依据断言','过度拒答']};
const clone=x=>JSON.parse(JSON.stringify(x));
const now=()=>new Date().toISOString();
const fail=m=>{throw new Error(m)};
function text(x,label,max=20000){if(typeof x!=='string'||!x.trim()||x.trim().length>max)fail(`${label}不能为空且长度不能超过${max}`);return x.trim()}
function choice(x,values,label){if(!values.includes(x))fail(`${label}无效`);return x}
function checkAnnotation(d){
 for(const dim of rubric.dimensions)if(!Number.isInteger(d.scores?.[dim.key])||d.scores[dim.key]<1||d.scores[dim.key]>5)fail('每个维度必须是1到5的整数');
 text(d.rationale,'评分理由');text(d.annotator,'标注人',100);
 if(!Array.isArray(d.error_types)||!d.error_types.length||d.error_types.some(x=>!rubric.error_types.includes(x))||new Set(d.error_types).size!==d.error_types.length)fail('请选择有效且不重复的错误类型');
 if(d.error_types.includes('无')&&d.error_types.length>1)fail('“无”不能与其他错误类型同时选择');
 choice(d.annotation_source??'human',['human','ai_assisted'],'标注来源');
}
export class DemoAPI{
 constructor(seed,storage){
  this.storage=storage;this.key='eval-workbench-demo-v1';
  const saved=storage.getItem(this.key);
  if(saved){try{this.state=JSON.parse(saved);if(this.state.schema!==1||!Array.isArray(this.state.tasks)||!this.state.history)fail('损坏')}catch{fail('浏览器数据无法读取。请先导出或备份浏览器数据，不要直接清除存储。')}}
  else{this.state={schema:1,tasks:[],history:{},feedback:[],nextTask:1,nextAnswer:1,nextFeedback:1};this.importData(seed);this.persist()}
 }
 persist(){try{this.storage.setItem(this.key,JSON.stringify(this.state))}catch{fail('浏览器存储写入失败，可能已满或禁用；请导出数据后检查存储设置')}}
 findTask(id){return this.state.tasks.find(t=>t.id===Number(id))??fail('题目不存在')}
 findAnswer(id){for(const t of this.state.tasks){const a=t.answers.find(a=>a.id===Number(id));if(a)return {t,a}}fail('回答不存在')}
 checkVersion(t,a,v){if(t.archived)fail('题目已归档');if(!Number.isInteger(v)||a.version!==v)fail('记录已被修改，请刷新后重试；你的输入尚未保存')}
 filtered(p={}){return this.state.tasks.filter(t=>!t.archived&&
  (!(p.real_only===true||p.real_only==='true')||t.provenance!=='demo')&&(!p.category||t.category===p.category)&&
  (!p.q||[t.prompt,t.reference,...t.answers.flatMap(a=>[a.text,a.model])].some(s=>s.toLowerCase().includes(p.q.toLowerCase())))&&
  (!p.status||(p.status==='pending'?(!t.answers.length||t.answers.some(a=>!a.annotation)):t.answers.some(a=>a.annotation?.status===p.status))))}
 createTask(d){
  const task={id:this.state.nextTask++,prompt:text(d.prompt,'题目'),reference:typeof d.reference==='string'?d.reference:'',category:text(d.category||'综合','分类',100),
   provenance:choice(d.provenance??'demo',['demo','model','human'],'数据来源'),archived:false,created_at:now(),answers:[]};
  if(task.reference.length>20000)fail('参考答案过长');this.state.tasks.push(task);return task;
 }
 addAnswer(t,d){
  if(t.archived)fail('题目已归档');
  const source=choice(d.source,['synthetic_demo','model_output','human_written'],'回答来源');
  if(t.provenance!=='demo'&&source==='synthetic_demo')fail('真实数据题目不能添加合成演示回答');
  if(t.answers.length>=50)fail('单题最多50个回答');
  const a={id:this.state.nextAnswer++,task_id:t.id,model:text(d.model,'模型标识',100),text:text(d.text,'回答'),source,version:0,created_at:now(),annotation:null};t.answers.push(a);return a;
 }
 annotate(t,a,d){
  this.checkVersion(t,a,d.expected_version);checkAnnotation(d);
  const total=Math.round(rubric.dimensions.reduce((sum,x)=>sum+d.scores[x.key]*x.weight*20,0)*10)/10;
  a.annotation={answer_id:a.id,scores:clone(d.scores),rationale:d.rationale.trim(),error_types:clone(d.error_types),annotator:d.annotator.trim(),annotation_source:d.annotation_source??'human',
   rubric_version:'1.0',status:'submitted',reviewer:null,review_note:null,total_score:total,version:++a.version,updated_at:now()};
  this.history(a,'annotation',a.annotation.annotator);return a.annotation;
 }
 history(a,event,actor){(this.state.history[a.id]??=[]).push({answer_id:a.id,version:a.version,event,actor,snapshot:clone(a.annotation),created_at:now()})}
 importData(d){
  if(d.schema_version!==1||!Array.isArray(d.tasks)||!d.tasks.length||d.tasks.length>500)fail('导入必须为schema_version=1，包含1至500道题目');
  for(const raw of d.tasks){if(raw.answers&&!Array.isArray(raw.answers))fail('answers 必须是数组');if((raw.answers?.length??0)>50)fail('单题最多50个回答');const t=this.createTask(raw);
   for(const item of raw.answers??[]){const a=this.addAnswer(t,item);if(item.annotation)this.annotate(t,a,{...item.annotation,expected_version:0})}}
  return {imported:d.tasks.length};
 }
 stats(p){
  const tasks=this.filtered(p),answers=tasks.flatMap(t=>t.answers),done=answers.filter(a=>a.annotation),errors={},models=new Map();
  for(const a of answers){if(!models.has(a.model))models.set(a.model,{model:a.model,answers:0,annotated:0,sum:0});const m=models.get(a.model);m.answers++;
   if(a.annotation){m.annotated++;m.sum+=a.annotation.total_score;for(const e of a.annotation.error_types)if(e!=='无')errors[e]=(errors[e]??0)+1}}
  return {tasks:tasks.length,answers:answers.length,annotated:done.length,pending:answers.length-done.length,reviewed:done.filter(a=>a.annotation.status==='approved').length,
   needs_revision:done.filter(a=>a.annotation.status==='needs_revision').length,human_annotations:done.filter(a=>a.annotation.annotation_source==='human').length,
   average_score:done.length?Math.round(done.reduce((s,a)=>s+a.annotation.total_score,0)/done.length*10)/10:null,errors,
   models:[...models.values()].map(m=>({model:m.model,answers:m.answers,annotated:m.annotated,average_score:m.annotated?Math.round(m.sum/m.annotated*10)/10:null}))};
 }
 exportData(p){return {schema_version:1,tasks:this.filtered(p).map(t=>({prompt:t.prompt,reference:t.reference,category:t.category,provenance:t.provenance,answers:t.answers.map(a=>{
  const d={model:a.model,text:a.text,source:a.source};if(a.annotation){const n=a.annotation;d.annotation={scores:n.scores,rationale:n.rationale,error_types:n.error_types,annotator:n.annotator,annotation_source:n.annotation_source}}return d})}))}}
 csv(p){
  const keys=['task_id','prompt','reference','category','provenance','answer_id','model','answer','source','correctness','instruction','completeness','clarity','total_score','rationale','error_types','annotator','annotation_source','status','reviewer','review_note','rubric_version','version'];
  const cell=v=>{let s=String(v??'');if(/^[\s]*[=+\-@\t\r]/.test(s))s="'"+s;return '"'+s.replaceAll('"','""')+'"'};
  const rows=[keys.join(',')];for(const t of this.filtered(p)){for(const a of t.answers.length?t.answers:[null]){const n=a?.annotation;
   const r={...t,task_id:t.id,answer_id:a?.id,model:a?.model,answer:a?.text,source:a?.source,version:a?.version,...n,...n?.scores,error_types:n?.error_types.join('；')};
   rows.push(keys.map(k=>cell(r[k])).join(','))}}return '\ufeff'+rows.join('\r\n')+'\r\n';
 }
 async request(method,path,data=null,p={}){
  // Refresh shared browser state before version checks (another tab may have saved).
  const saved=this.storage.getItem(this.key);
  if(saved){try{this.state=JSON.parse(saved)}catch{fail('浏览器数据无法读取，请先备份浏览器数据')}}
  const backup=method==='GET'?null:clone(this.state);let result;
  try{
   if(method==='GET'&&path==='/api/meta')return {mode:'demo',rubric,categories:['综合','数学','代码','SQL','信息提取','逻辑','事实问答','写作'],storage:'网页演示 · 当前浏览器存储',auth_required:false};
   if(method==='GET'&&path==='/api/tasks'){const rows=[...this.filtered(p)].reverse();const offset=Number(p.offset??0),limit=Number(p.limit??50);return clone({items:rows.slice(offset,offset+limit),total:rows.length,offset,limit})}
   if(method==='GET'&&path==='/api/stats')return this.stats(p);
   if(method==='GET'&&path==='/api/export')return p.format==='csv'?this.csv(p):clone(this.exportData(p));
   if(method==='GET'&&path==='/api/feedback')return clone([...this.state.feedback].reverse());
   let m=path.match(/^\/api\/tasks\/(\d+)$/);if(m&&method==='GET')return clone(this.findTask(m[1]));
   m=path.match(/^\/api\/answers\/(\d+)\/history$/);if(m&&method==='GET'){this.findAnswer(m[1]);return clone(this.state.history[m[1]]??[])}
   if(method==='POST'&&path==='/api/tasks')result=this.createTask(data);
   else if(method==='POST'&&path==='/api/import')result=this.importData(data);
   else if((m=path.match(/^\/api\/tasks\/(\d+)\/answers$/))&&method==='POST')result=this.addAnswer(this.findTask(m[1]),data);
   else if((m=path.match(/^\/api\/tasks\/(\d+)\/archive$/))&&method==='POST'){result=this.findTask(m[1]);result.archived=true}
   else if((m=path.match(/^\/api\/answers\/(\d+)\/annotations$/))&&method==='POST'){const {t,a}=this.findAnswer(m[1]);result=this.annotate(t,a,data)}
   else if((m=path.match(/^\/api\/answers\/(\d+)\/review$/))&&method==='POST'){
    const {t,a}=this.findAnswer(m[1]);this.checkVersion(t,a,data.expected_version);if(!a.annotation)fail('请先完成标注');
    const actor=text(data.reviewer,'复核人',100);if(actor.toLowerCase()===a.annotation.annotator.toLowerCase())fail('复核人与标注人不能相同');
    a.annotation={...a.annotation,status:choice(data.decision,['approved','needs_revision'],'复核结论'),reviewer:actor,review_note:text(data.note,'复核说明'),version:++a.version,updated_at:now()};this.history(a,'review',actor);result=a.annotation;
   }else if(method==='POST'&&path==='/api/feedback'){
    result={id:this.state.nextFeedback++,content:text(data.content,'反馈内容'),reporter:text(data.reporter,'反馈人',100),status:'open',resolution:'',created_at:now()};this.state.feedback.push(result);
   }else if((m=path.match(/^\/api\/feedback\/(\d+)$/))&&method==='PUT'){
    result=this.state.feedback.find(f=>f.id===Number(m[1]))??fail('反馈不存在');const status=choice(data.status,['open','resolved'],'处理状态');
    result.resolution=status==='resolved'?text(data.resolution,'处理说明'):String(data.resolution??'');result.status=status;
   }else fail('不支持的操作');
   this.persist();return clone(result);
  }catch(e){if(backup)this.state=backup;throw e}
 }
}
