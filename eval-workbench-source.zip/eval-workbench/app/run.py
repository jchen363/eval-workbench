"""Safe local/container entrypoint: python -m app.run."""
import os
import uvicorn

if __name__ == '__main__':
    host = os.environ.get('EVAL_HOST','127.0.0.1')
    if host not in ('127.0.0.1','localhost','::1') and len(os.environ.get('EVAL_TOKEN','')) < 24:
        raise SystemExit('外网监听必须配置至少24字符的 EVAL_TOKEN')
    uvicorn.run('app.main:app',host=host,port=int(os.environ.get('PORT','8765')),workers=1)
