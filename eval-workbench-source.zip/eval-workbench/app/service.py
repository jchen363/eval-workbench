import csv
import io
import json

from fastapi import HTTPException

from .models import RUBRIC


def require(row, message='记录不存在'):
    if row is None:
        raise HTTPException(404, message)
    return row


def annotation_dict(row):
    if row is None:
        return None
    d = dict(row)
    d['scores'] = {x['key']: d.pop(x['key']) for x in RUBRIC['dimensions']}
    d['error_types'] = json.loads(d['error_types'])
    return d


def answer_dict(con, row):
    d = dict(row)
    d['annotation'] = annotation_dict(con.execute('SELECT * FROM annotations WHERE answer_id=?',(d['id'],)).fetchone())
    if d['annotation']:
        d['annotation']['version'] = d['version']
    return d


def task_dict(con, row):
    d = dict(row)
    d['archived'] = bool(d['archived'])
    d['answers'] = [answer_dict(con,r) for r in con.execute('SELECT * FROM answers WHERE task_id=? ORDER BY id',(d['id'],))]
    return d


def conditions(q='', category='', status='', real_only=False):
    clauses, args = ['t.archived=0'], []
    if q:
        clauses.append('(instr(lower(t.prompt), lower(?)) > 0 OR instr(lower(t.reference),lower(?)) > 0 OR EXISTS (SELECT 1 FROM answers x WHERE x.task_id=t.id AND (instr(lower(x.text),lower(?)) > 0 OR instr(lower(x.model),lower(?)) > 0)))')
        args.extend([q]*4)
    if category:
        clauses.append('t.category=?')
        args.append(category)
    if real_only:
        clauses.append("t.provenance != 'demo'")
    if status == 'pending':
        clauses.append('(NOT EXISTS(SELECT 1 FROM answers x WHERE x.task_id=t.id) OR EXISTS(SELECT 1 FROM answers x LEFT JOIN annotations n ON n.answer_id=x.id WHERE x.task_id=t.id AND n.answer_id IS NULL))')
    elif status:
        clauses.append('EXISTS(SELECT 1 FROM answers x JOIN annotations n ON n.answer_id=x.id WHERE x.task_id=t.id AND n.status=?)')
        args.append(status)
    return ' AND '.join(clauses), args


class Service:
    def __init__(self, db):
        self.db = db

    def get_task(self, task_id):
        with self.db.connect() as c:
            return task_dict(c,require(c.execute('SELECT * FROM tasks WHERE id=?',(task_id,)).fetchone()))

    def list_tasks(self, limit=50, offset=0, **filters):
        where,args = conditions(**filters)
        with self.db.connect() as c:
            total = c.execute('SELECT count(*) FROM tasks t WHERE '+where,args).fetchone()[0]
            rows = c.execute('SELECT t.* FROM tasks t WHERE '+where+' ORDER BY t.id DESC LIMIT ? OFFSET ?',[*args,limit,offset]).fetchall()
            return {'items':[task_dict(c,r) for r in rows], 'total':total,'limit':limit,'offset':offset}

    def _add_task(self,c,data):
        cur = c.execute('INSERT INTO tasks(prompt,reference,category,provenance) VALUES (?,?,?,?)',
                        (data.prompt,data.reference,data.category,data.provenance))
        return cur.lastrowid

    def create_task(self,data):
        with self.db.connect(write=True) as c:
            tid = self._add_task(c,data)
        return self.get_task(tid)

    def _add_answer(self,c,task_id,data):
        t = require(c.execute('SELECT * FROM tasks WHERE id=?',(task_id,)).fetchone())
        if t['archived']:
            raise HTTPException(409,'题目已归档，不能新增回答')
        # A real-data task must not silently mix in synthetic candidates.
        if t['provenance'] != 'demo' and data.source == 'synthetic_demo':
            raise HTTPException(422,'真实数据题目不能添加合成演示回答，请调整数据来源')
        return c.execute('INSERT INTO answers(task_id,model,text,source) VALUES (?,?,?,?)',(task_id,data.model,data.text,data.source)).lastrowid

    def add_answer(self,task_id,data):
        with self.db.connect(write=True) as c:
            aid = self._add_answer(c,task_id,data)
            return answer_dict(c,c.execute('SELECT * FROM answers WHERE id=?',(aid,)).fetchone())

    def archive(self,task_id):
        with self.db.connect(write=True) as c:
            require(c.execute('SELECT id FROM tasks WHERE id=?',(task_id,)).fetchone())
            c.execute('UPDATE tasks SET archived=1 WHERE id=?',(task_id,))
        return self.get_task(task_id)

    def _writable_answer(self,c,aid,expected_version):
        row = require(c.execute('SELECT a.*,t.archived FROM answers a JOIN tasks t ON t.id=a.task_id WHERE a.id=?',(aid,)).fetchone())
        if row['archived']:
            raise HTTPException(409,'题目已归档')
        if row['version'] != expected_version:
            raise HTTPException(409,'记录已被修改，请刷新后重试；你的输入尚未保存')
        return row

    def _history(self,c,aid,event,actor,version):
        d = annotation_dict(c.execute('SELECT * FROM annotations WHERE answer_id=?',(aid,)).fetchone())
        d['version'] = version
        c.execute('INSERT INTO annotation_history(answer_id,version,event,actor,snapshot) VALUES (?,?,?,?,?)',
                  (aid,version,event,actor,json.dumps(d,ensure_ascii=False)))
        c.execute('UPDATE answers SET version=? WHERE id=?',(version,aid))
        return d

    def _annotate(self,c,aid,data,expected_version):
        self._writable_answer(c,aid,expected_version)
        s = data.scores
        total = round((s.correctness*.4+s.instruction*.3+s.completeness*.2+s.clarity*.1)*20,1)
        values = (aid,s.correctness,s.instruction,s.completeness,s.clarity,total,data.rationale,
                  json.dumps(data.error_types,ensure_ascii=False),data.annotator,data.annotation_source,'1.0','submitted')
        c.execute('''INSERT INTO annotations(answer_id,correctness,instruction,completeness,clarity,total_score,rationale,error_types,annotator,annotation_source,rubric_version,status)
          VALUES (?,?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(answer_id) DO UPDATE SET
          correctness=excluded.correctness,instruction=excluded.instruction,completeness=excluded.completeness,
          clarity=excluded.clarity,total_score=excluded.total_score,rationale=excluded.rationale,error_types=excluded.error_types,
          annotator=excluded.annotator,annotation_source=excluded.annotation_source,rubric_version=excluded.rubric_version,
          status='submitted',reviewer=NULL,review_note=NULL,updated_at=strftime('%Y-%m-%dT%H:%M:%fZ','now')''',values)
        return self._history(c,aid,'annotation',data.annotator,expected_version+1)

    def annotate(self,aid,data):
        with self.db.connect(write=True) as c:
            return self._annotate(c,aid,data,data.expected_version)

    def review(self,aid,data):
        with self.db.connect(write=True) as c:
            self._writable_answer(c,aid,data.expected_version)
            row = c.execute('SELECT * FROM annotations WHERE answer_id=?',(aid,)).fetchone()
            if not row:
                raise HTTPException(422,'请先完成标注')
            if row['annotator'].strip().casefold() == data.reviewer.strip().casefold():
                raise HTTPException(422,'复核人与标注人不能相同')
            c.execute("UPDATE annotations SET status=?,reviewer=?,review_note=?,updated_at=strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE answer_id=?",(data.decision,data.reviewer,data.note,aid))
            return self._history(c,aid,'review',data.reviewer,data.expected_version+1)

    def history(self,aid):
        with self.db.connect() as c:
            require(c.execute('SELECT id FROM answers WHERE id=?',(aid,)).fetchone())
            result = []
            for row in c.execute('SELECT * FROM annotation_history WHERE answer_id=? ORDER BY version',(aid,)):
                d = dict(row)
                d['snapshot'] = json.loads(d['snapshot'])
                result.append(d)
            return result

    def import_data(self,data):
        with self.db.connect(write=True) as c:
            for t in data.tasks:
                tid = self._add_task(c,t)
                for a in t.answers:
                    aid = self._add_answer(c,tid,a)
                    if a.annotation:
                        self._annotate(c,aid,a.annotation,0)
        return {'imported':len(data.tasks)}

    def export_data(self,**filters):
        where,args = conditions(**filters)
        with self.db.connect() as c:
            tasks = [task_dict(c,r) for r in c.execute('SELECT t.* FROM tasks t WHERE '+where+' ORDER BY t.id',args).fetchall()]
        exported = []
        for t in tasks:
            item = {key:t[key] for key in ('prompt','reference','category','provenance')}
            item['answers'] = []
            for a in t['answers']:
                out = {key:a[key] for key in ('model','text','source')}
                if a['annotation']:
                    out['annotation'] = {key:a['annotation'][key] for key in ('scores','rationale','error_types','annotator','annotation_source')}
                item['answers'].append(out)
            exported.append(item)
        # This is an interchange format, not an audit backup. Full backups use sqlite.backup.
        return {'schema_version':1,'tasks':exported},tasks

    def csv_export(self,tasks):
        out = io.StringIO()
        keys = ['task_id','prompt','reference','category','provenance','answer_id','model','answer','source',
                'correctness','instruction','completeness','clarity','total_score','rationale','error_types',
                'annotator','annotation_source','status','reviewer','review_note','rubric_version','version']
        writer = csv.DictWriter(out,fieldnames=keys)
        writer.writeheader()
        def safe(value):
            s = str(value if value is not None else '')
            return "'"+s if s.lstrip().startswith(('=','+','-','@','\t','\r')) else s
        for t in tasks:
            for a in t['answers'] or [None]:
                row = dict(task_id=t['id'],**{k:t[k] for k in ('prompt','reference','category','provenance')})
                if a:
                    row.update(answer_id=a['id'],model=a['model'],answer=a['text'],source=a['source'],version=a['version'])
                    if a['annotation']:
                        n = a['annotation']
                        row.update(n['scores'])
                        row.update({k:n[k] for k in ('total_score','rationale','annotator','annotation_source','status','reviewer','review_note','rubric_version')})
                        row['error_types'] = '；'.join(n['error_types'])
                writer.writerow({k:safe(v) for k,v in row.items()})
        return '\ufeff'+out.getvalue()

    def stats(self,**filters):
        where,args = conditions(**filters)
        with self.db.connect() as c:
            count = c.execute('SELECT count(*) FROM tasks t WHERE '+where,args).fetchone()[0]
            rows = c.execute('''SELECT a.id,a.model,a.source,n.total_score,n.status,n.error_types,n.annotation_source
                FROM tasks t JOIN answers a ON a.task_id=t.id LEFT JOIN annotations n ON n.answer_id=a.id WHERE '''+where,args).fetchall()
        done = [r for r in rows if r['total_score'] is not None]
        errors,models = {},{}
        for r in rows:
            m = models.setdefault(r['model'],{'model':r['model'],'answers':0,'annotated':0,'score_sum':0})
            m['answers'] += 1
            if r['total_score'] is not None:
                m['annotated'] += 1
                m['score_sum'] += r['total_score']
                for e in json.loads(r['error_types']):
                    if e != '无': errors[e] = errors.get(e,0)+1
        for m in models.values():
            m['average_score'] = round(m.pop('score_sum')/m['annotated'],1) if m['annotated'] else None
        return {'tasks':count,'answers':len(rows),'annotated':len(done),'pending':len(rows)-len(done),
                'reviewed':sum(r['status']=='approved' for r in done),
                'needs_revision':sum(r['status']=='needs_revision' for r in done),
                'human_annotations':sum(r['annotation_source']=='human' for r in done),
                'average_score':round(sum(r['total_score'] for r in done)/len(done),1) if done else None,
                'errors':errors,'models':list(models.values())}

    def feedback(self):
        with self.db.connect() as c:
            return [dict(r) for r in c.execute('SELECT * FROM feedback ORDER BY id DESC')]

    def add_feedback(self,data):
        with self.db.connect(write=True) as c:
            fid = c.execute('INSERT INTO feedback(content,reporter) VALUES (?,?)',(data.content,data.reporter)).lastrowid
            return dict(c.execute('SELECT * FROM feedback WHERE id=?',(fid,)).fetchone())

    def update_feedback(self,fid,data):
        with self.db.connect(write=True) as c:
            require(c.execute('SELECT id FROM feedback WHERE id=?',(fid,)).fetchone())
            c.execute('UPDATE feedback SET status=?,resolution=? WHERE id=?',(data.status,data.resolution,fid))
            return dict(c.execute('SELECT * FROM feedback WHERE id=?',(fid,)).fetchone())
