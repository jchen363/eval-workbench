import sqlite3
from contextlib import contextmanager
from pathlib import Path

SCHEMA = '''
CREATE TABLE IF NOT EXISTS tasks (
 id INTEGER PRIMARY KEY, prompt TEXT NOT NULL, reference TEXT NOT NULL DEFAULT '',
 category TEXT NOT NULL, provenance TEXT NOT NULL CHECK(provenance IN ('demo','model','human')),
 archived INTEGER NOT NULL DEFAULT 0 CHECK(archived IN (0,1)),
 created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);
CREATE TABLE IF NOT EXISTS answers (
 id INTEGER PRIMARY KEY, task_id INTEGER NOT NULL REFERENCES tasks(id),
 model TEXT NOT NULL, text TEXT NOT NULL,
 source TEXT NOT NULL CHECK(source IN ('synthetic_demo','model_output','human_written')),
 version INTEGER NOT NULL DEFAULT 0,
 created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);
CREATE TABLE IF NOT EXISTS annotations (
 answer_id INTEGER PRIMARY KEY REFERENCES answers(id),
 correctness INTEGER NOT NULL CHECK(correctness BETWEEN 1 AND 5),
 instruction INTEGER NOT NULL CHECK(instruction BETWEEN 1 AND 5),
 completeness INTEGER NOT NULL CHECK(completeness BETWEEN 1 AND 5),
 clarity INTEGER NOT NULL CHECK(clarity BETWEEN 1 AND 5),
 total_score REAL NOT NULL CHECK(total_score BETWEEN 20 AND 100),
 rationale TEXT NOT NULL, error_types TEXT NOT NULL, annotator TEXT NOT NULL,
 annotation_source TEXT NOT NULL CHECK(annotation_source IN ('human','ai_assisted')),
 rubric_version TEXT NOT NULL CHECK(rubric_version='1.0'),
 status TEXT NOT NULL CHECK(status IN ('submitted','approved','needs_revision')),
 reviewer TEXT, review_note TEXT,
 updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);
CREATE TABLE IF NOT EXISTS annotation_history (
 id INTEGER PRIMARY KEY, answer_id INTEGER NOT NULL REFERENCES answers(id),
 version INTEGER NOT NULL, event TEXT NOT NULL, actor TEXT NOT NULL,
 snapshot TEXT NOT NULL,
 created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
 UNIQUE(answer_id,version)
);
CREATE TABLE IF NOT EXISTS feedback (
 id INTEGER PRIMARY KEY, content TEXT NOT NULL, reporter TEXT NOT NULL,
 status TEXT NOT NULL DEFAULT 'open' CHECK(status IN ('open','resolved')),
 resolution TEXT NOT NULL DEFAULT '',
 created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);
CREATE INDEX IF NOT EXISTS idx_tasks_category_archived ON tasks(archived,category);
CREATE INDEX IF NOT EXISTS idx_answers_task ON answers(task_id);
CREATE INDEX IF NOT EXISTS idx_answers_model ON answers(model);
CREATE INDEX IF NOT EXISTS idx_annotations_status ON annotations(status);
PRAGMA user_version=1;
'''


class Database:
    def __init__(self, path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with self.connect() as con:
            con.execute('PRAGMA journal_mode=WAL')
            con.executescript(SCHEMA)

    @contextmanager
    def connect(self, write=False):
        con = sqlite3.connect(self.path, timeout=5)
        con.row_factory = sqlite3.Row
        con.execute('PRAGMA foreign_keys=ON')
        con.execute('PRAGMA busy_timeout=5000')
        try:
            if write:
                con.execute('BEGIN IMMEDIATE')
            yield con
            if write:
                con.commit()
        except Exception:
            con.rollback()
            raise
        finally:
            con.close()
