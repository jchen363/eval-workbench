"""A small, auditable LLM evaluation workbench."""
