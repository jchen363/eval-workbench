import hmac
import logging
import os
import sqlite3
from pathlib import Path
from typing import Literal
from urllib.parse import urlparse

from fastapi import Depends, FastAPI, Query, Request
from fastapi.responses import FileResponse, JSONResponse, Response
from fastapi.staticfiles import StaticFiles

from .db import Database
from .models import (RUBRIC, AnnotationIn, AnswerIn, FeedbackIn, FeedbackUpdate,
                     ImportIn, ReviewIn, TaskIn)
from .service import Service

STATIC = Path(__file__).parent / 'static'
DEFAULT_DB = Path(__file__).resolve().parent.parent / 'data' / 'local.sqlite'
log = logging.getLogger('eval-workbench')


def create_app(db_path=DEFAULT_DB, token='', ephemeral=False):
    api = FastAPI(title='Eval Workbench API',version='1.0.0',docs_url='/api/docs',openapi_url='/api/openapi.json')
    service = Service(Database(db_path))
    api.state.service = service

    @api.middleware('http')
    async def boundaries(request: Request, call_next):
        # Protect CLI/local deployments against drive-by browser writes.
        if request.method in ('POST','PUT','PATCH','DELETE'):
            origin = request.headers.get('origin')
            if request.headers.get('sec-fetch-site') == 'cross-site' or (origin and urlparse(origin).netloc != request.headers.get('host')):
                return JSONResponse({'detail':'拒绝跨站写入请求'},403)
        if request.url.path.startswith('/api/') and token:
            if not hmac.compare_digest(request.headers.get('authorization',''), 'Bearer '+token):
                return JSONResponse({'detail':'请输入访问令牌'},401)
        if request.url.path.startswith('/api/') and request.method in ('POST','PUT','PATCH'):
            body = await request.body()
            if len(body) > 2_000_000:
                return JSONResponse({'detail':'请求不能超过 2 MB'},413)
        response = await call_next(request)
        response.headers['X-Content-Type-Options'] = 'nosniff'
        response.headers['Referrer-Policy'] = 'same-origin'
        response.headers['Content-Security-Policy'] = "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; frame-ancestors 'self'; base-uri 'none'; form-action 'self'"
        if request.url.path == '/api/docs':
            response.headers['Content-Security-Policy'] = "default-src 'self'; script-src 'unsafe-inline' https://cdn.jsdelivr.net; style-src 'unsafe-inline' https://cdn.jsdelivr.net; img-src 'self' data: https://fastapi.tiangolo.com; connect-src 'self'; frame-ancestors 'self'"
        if request.url.path.startswith('/api/'):
            response.headers['Cache-Control'] = 'no-store'
        return response

    @api.exception_handler(sqlite3.OperationalError)
    async def database_unavailable(request,exc):
        log.exception('Database operation failed')
        return JSONResponse({'detail':'数据库暂时不可用，请稍后重试'},503)

    def filters(q: str = Query('',max_length=200),category: str = Query('',max_length=100),
                status: Literal['','pending','submitted','approved','needs_revision']='',real_only: bool=False):
        return dict(q=q,category=category,status=status,real_only=real_only)

    @api.get('/health')
    def health():
        with service.db.connect() as c:
            c.execute('SELECT 1').fetchone()
        return {'status':'ok','storage':'sqlite','version':'1.0.0'}

    @api.get('/api/meta')
    def meta():
        return {'mode':'python','rubric':RUBRIC,'categories':['综合','数学','代码','SQL','信息提取','逻辑','事实问答','写作'],
                'storage':'临时 SQLite；重启或重新部署可能丢失数据' if ephemeral else 'Python API + SQLite；单实例持久化',
                'ephemeral':ephemeral,'auth_required':bool(token)}

    @api.get('/api/tasks')
    def list_tasks(limit: int=Query(50,ge=1,le=100),offset: int=Query(0,ge=0),f=Depends(filters)):
        return service.list_tasks(limit,offset,**f)

    @api.post('/api/tasks',status_code=201)
    def create_task(data: TaskIn):
        return service.create_task(data)

    @api.get('/api/tasks/{task_id}')
    def get_task(task_id:int):
        return service.get_task(task_id)

    @api.post('/api/tasks/{task_id}/archive')
    def archive(task_id:int):
        return service.archive(task_id)

    @api.post('/api/tasks/{task_id}/answers',status_code=201)
    def add_answer(task_id:int,data:AnswerIn):
        return service.add_answer(task_id,data)

    @api.post('/api/answers/{answer_id}/annotations')
    def annotate(answer_id:int,data:AnnotationIn):
        return service.annotate(answer_id,data)

    @api.post('/api/answers/{answer_id}/review')
    def review(answer_id:int,data:ReviewIn):
        return service.review(answer_id,data)

    @api.get('/api/answers/{answer_id}/history')
    def history(answer_id:int):
        return service.history(answer_id)

    @api.get('/api/stats')
    def stats(f=Depends(filters)):
        return service.stats(**f)

    @api.post('/api/import')
    def import_data(data:ImportIn):
        return service.import_data(data)

    @api.get('/api/export')
    def export(format:Literal['csv','json']='json',f=Depends(filters)):
        canonical,tasks = service.export_data(**f)
        headers = {'Content-Disposition':f'attachment; filename="eval-export.{format}"'}
        if format == 'json':
            return JSONResponse(canonical,headers=headers)
        return Response(service.csv_export(tasks),media_type='text/csv; charset=utf-8',headers=headers)

    @api.get('/api/feedback')
    def list_feedback():
        return service.feedback()

    @api.post('/api/feedback',status_code=201)
    def add_feedback(data:FeedbackIn):
        return service.add_feedback(data)

    @api.put('/api/feedback/{feedback_id}')
    def update_feedback(feedback_id:int,data:FeedbackUpdate):
        return service.update_feedback(feedback_id,data)

    @api.get('/')
    def index():
        return FileResponse(STATIC/'index.html') if (STATIC/'index.html').exists() else Response('Eval Workbench',media_type='text/plain')

    api.mount('/static',StaticFiles(directory=STATIC),name='static')
    return api


app = create_app(os.environ.get('EVAL_DB',DEFAULT_DB),os.environ.get('EVAL_TOKEN',''),os.environ.get('EVAL_EPHEMERAL')=='1')
