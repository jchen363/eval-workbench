# Eval Workbench Implementation Plan

> **For agentic workers:** Use superpowers:executing-plans to implement this plan task-by-task. User authorized autonomous inline execution.

**Goal:** 交付中文评测标注台、Python/SQL 后端与可复现的求职证据。

**Architecture:** FastAPI routes consume validated input models and delegate SQLite transactions to a service. Shared frontend uses HTTP in the full version and a visibly labelled browser-local adapter in the hosted demonstration.

**Tech Stack:** Python 3.11+, FastAPI, sqlite3, vanilla JS, pytest/httpx.

**Spec:** `docs/superpowers/specs/2026-11-26-eval-workbench-design.md`

## Global Constraints

- 四维 1–5 分，权重 40/30/20/10，量表 v1.0。
- 当前标注和历史分离；提交、复核使用版本校验。
- 样例来源必须标明；演示数据不得称为真实评测。
- SQLite 单实例；默认本机运行；发布不包含密钥、数据库或用户数据。

## Review Focus

- 过期编辑不能覆盖评分或复核；Task 1 测试。
- 导入后半部分非法时整批回滚；Task 1 测试。
- 多次修订不增加已标注数量或扭曲平均分；Task 1 测试。
- CSV 单元格中的公式前缀要转义；Task 1 测试。
- 演示与真实样本的筛选、来源、持久化在两个适配器保持一致；Task 3 浏览器检查。

### Task 1: Python API and SQL persistence

**Files:** `tests/test_api.py`, `app/{main,models,db,service}.py`, `requirements.txt`.

**Interfaces:** `create_app(db_path, token='') -> FastAPI`; tasks/answers/annotations/review/stats/export/import/feedback API. Full contracts documented in API doc.

- [ ] Write API behavior tests for create/query/archive, scoring validation, atomic review/history, import rollback, stats, export and token protection.
- [ ] Run pytest, observe expected missing-app failures, then implement models/schema/services/routes.
- [ ] Run full pytest suite and commit the backend.

### Task 2: Evaluation samples and reproducible analysis

**Files:** `data/demo.json`, `scripts/{seed,analyze,benchmark,backup}.py`, tests for source filtering and seed idempotence.

**Interfaces:** JSON import/export schema v1; statistical report from current annotations only.

- [ ] Test demo exclusion and import persistence before implementing.
- [ ] Create grounded synthetic tasks with known answers, positive and negative candidate responses, scoring reasons and provenance.
- [ ] Produce a computed evaluation report and measured local benchmark; label limits.

### Task 3: Web application and hosted demonstration

**Files:** `app/static/{index.html,style.css,app.js,demo.js,demo.json}` and hosted static project.

**Interfaces:** API adapter `get/post/put`, same JSON contracts as Task 1; demo mode persists in browser localStorage with visible disclosure.

- [ ] Verify workflow against HTTP API; implement task list, forms, rubric, history, review, analytics, import/export and feedback.
- [ ] Check create/save/reload, validation, review, filters, empty state and narrow screen in a real browser.
- [ ] Publish packaged static demonstration through Sites and verify native deployment result.

### Task 4: Delivery and evidence

**Files:** README, Dockerfile, compose.yaml, docs, test report, archive.

**Interfaces:** `python -m uvicorn app.main:app --host 127.0.0.1 --port 8765`, `pytest`, Docker entrypoint with mounted `/data`.

- [ ] Write usage, requirements, architecture/schema, evaluation, deployment and interview notes.
- [ ] Run full tests, backup integrity and final smoke checks.
- [ ] Obtain one independent whole-project review, address material findings, and package source without secrets/runtime data.
- [ ] Report exact accessible links, measured checks, and cloud/full-backend limitations.
