# Eval Workbench · 大模型评测标注台

Python + FastAPI + SQLite 的个人工程项目。支持录题、录回答、四维评分、错误分类、另一位操作者复核、版本历史、筛选分析、JSON/CSV 导入导出与反馈记录。

**状态说明：** Python 完整版已在本机实际运行与验证；线上网页是浏览器存储演示，不能代表 Python 后端已上云。默认样例为12道合成题目、24条候选回答，其中16条AI初评，0条真实人工复核。没有外部模型API调用、真实双人评测或实际团队协作的证明。

## 运行（Python 3.12 推荐）

在本目录打开终端：

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python -m scripts.seed
python -m app.run
```

打开 [本机工作台](http://127.0.0.1:8765)。API文档为 `/api/docs`。`scripts.seed` 只在空数据库中导入样例，已有数据时会跳过。启动不会自动重新填充数据；不用样例可以跳过 seed。

本次交付环境已安装好依赖，可直接从项目目录运行：

```bash
../../work/venv/bin/python -m app.run
```

数据库默认 `data/local.sqlite`，可通过 `EVAL_DB` 改路径。数据属于单实例，不跨设备共享。

## 操作一遍完整流程

1. 新建题目，写明任务、约束、参考要点与来源。
2. 录入回答，填写模型版本、原文及真实来源。
3. 阅读参考答案，分别打四维分数，选择错误类型，写具体理由。
4. 填写操作者与标注方式，保存提交。
5. 另一位实际参与者检查后提交通过或退回；修订会形成新版本并重新待复核。
6. 查看评测分析，按需要筛选，导出CSV分析或JSON交换。

姓名只是声明信息，不验证账号。个人项目不能靠换名操作制造真实多人协作经历。

## 测试与分析

```bash
python -m pip install -r requirements-dev.txt
python -m pytest -q
node --test tests/demo.test.mjs
python -m scripts.analyze --output docs/05-样例分析结果.md
python -m scripts.benchmark --output docs/benchmark.json
python -m scripts.backup data/local.sqlite data/backup-2026-11-26.sqlite
```

备份命令使用SQLite一致性备份接口，包括WAL已提交数据、复核与历史。JSON交换格式不含原ID、复核结论和历史，重新导入会追加数据并重新待复核。恢复时应先停服务，再把完整SQLite备份复制到 `EVAL_DB` 指定位置。

## 文档

- [全部岗位职责、要求与证据对应](docs/01-岗位与证据.md)
- [需求、架构、数据库与API](docs/02-需求与技术设计.md)
- [评测规范与真实数据操作](docs/03-评测操作规范.md)
- [部署、维护与验证记录](docs/04-部署与验证.md)
- [样例分析结果](docs/05-样例分析结果.md)
- [简历与面试说明](docs/06-简历与面试.md)

## 工程边界

量表v1.0固定，不支持静默修改。单实例SQLite，无账号体系、无分布式并发承诺、无自动调用模型。外网部署使用 `python -m app.run`，必须配置至少24字符的 `EVAL_TOKEN`，并通过HTTPS访问。生产用持久卷，不能把SQLite放在会重置的临时文件系统。Docker配置已提供，但本环境没有执行容器构建。
