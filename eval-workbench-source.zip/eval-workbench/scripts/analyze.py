import argparse
import json
from pathlib import Path

from app.db import Database
from app.service import Service


def report(path,real_only=False):
    stats = Service(Database(path)).stats(real_only=real_only)
    lines = ['# 数据分析结果','',
             '统计口径：未归档题目；每个回答只使用当前标注；未标注回答不计平均分；错误类型可多选，因此比例之和可能超过100%。',
             '','本报告由 scripts/analyze.py 从 SQLite 实际计算，不能把合成样例得分解释为真实模型能力排名。',
             '',f"题目 {stats['tasks']}，回答 {stats['answers']}，已标注 {stats['annotated']}，人工标注 {stats['human_annotations']}，复核通过 {stats['reviewed']}。",'']
    for m in stats['models']:
        lines.append(f"- {m['model']}：回答 {m['answers']}，已标注 {m['annotated']}，均分 {m['average_score']}。")
    lines.extend(['','错误计数（分母为已标注回答数）：',''])
    for name,count in sorted(stats['errors'].items(),key=lambda x:-x[1]):
        lines.append(f"- {name}：{count}/{stats['annotated']}")
    lines.extend(['','解释：样例含有刻意构造的错误，且评分由 AI 初评，不独立、不盲测、不具备代表性。适用于核对业务流程与统计口径。正式评测应预先确定题集，记录模型版本与生成参数，由本人复核，并抽取争议样本做第二人复核。',''])
    return '\n'.join(lines)


if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('--db',default='data/local.sqlite')
    p.add_argument('--real-only',action='store_true')
    p.add_argument('--output')
    args = p.parse_args()
    text = report(args.db,args.real_only)
    if args.output:
        Path(args.output).write_text(text)
    else:
        print(text)
