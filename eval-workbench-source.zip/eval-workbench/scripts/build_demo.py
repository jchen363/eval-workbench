"""Build the static demo and a sanitized source download using stdlib only."""
import json
import shutil
import subprocess
import zipfile
from pathlib import Path

ROOT=Path(__file__).resolve().parent.parent

if __name__=='__main__':
    dist=ROOT/'dist'
    if dist.exists():
        shutil.rmtree(dist)
    (dist/'static').mkdir(parents=True)
    for path in (ROOT/'app/static').iterdir():
        if path.is_file():shutil.copy2(path,dist/'static'/path.name)
    shutil.copy2(ROOT/'app/static/index.html',dist/'index.html')
    (dist/'static/config.json').write_text(json.dumps({'mode':'demo'}))
    files=subprocess.check_output(['git','ls-files','-z'],cwd=ROOT).decode().split('\0')
    with zipfile.ZipFile(dist/'static/eval-workbench-source.zip','w',zipfile.ZIP_DEFLATED) as archive:
        for file in files:
            if not file or file.startswith(('.openai/','dist/')):continue
            path=ROOT/file
            if path.is_file():archive.write(path,'eval-workbench/'+file)
    print('Static demo and sanitized source download built.')
