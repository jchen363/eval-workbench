"""Local ASGI + SQLite smoke benchmark; not a production load test."""
import argparse
import json
import platform
import statistics
import tempfile
import time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

from fastapi.testclient import TestClient
from app.main import create_app
from scripts.seed import seed_demo


if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('--requests',type=int,default=200)
    p.add_argument('--workers',type=int,default=4)
    p.add_argument('--output')
    args = p.parse_args()
    if not (1 <= args.requests <= 10000 and 1 <= args.workers <= 32):
        p.error('requests 需在1到10000，workers需在1到32')
    with tempfile.TemporaryDirectory() as tmp:
        path = Path(tmp)/'bench.sqlite'
        seed_demo(path)
        with TestClient(create_app(path)) as client:
            def once(i):
                start = time.perf_counter()
                r = client.get('/api/tasks' if i%2 else '/api/stats')
                return (time.perf_counter()-start)*1000,r.status_code
            start = time.perf_counter()
            with ThreadPoolExecutor(max_workers=args.workers) as pool:
                results = list(pool.map(once,range(args.requests)))
            elapsed = time.perf_counter()-start
    times = sorted(t for t,status in results)
    result = {'scope':'local in-process ASGI + SQLite; 12 tasks / 24 answers; read requests only',
              'python':platform.python_version(),'platform':platform.platform(),'requests':args.requests,'workers':args.workers,
              'successes':sum(status==200 for _,status in results),'errors':sum(status!=200 for _,status in results),
              'p50_ms':round(statistics.median(times),2),'p95_ms':round(times[max(0,int(len(times)*.95)-1)],2),
              'elapsed_seconds':round(elapsed,3),'requests_per_second':round(args.requests/elapsed,1),
              'limitations':'Not HTTP network latency, not production SLA, not write/concurrency or large-dataset benchmark.'}
    output=json.dumps(result,ensure_ascii=False,indent=2)
    if args.output: Path(args.output).write_text(output)
    print(output)
