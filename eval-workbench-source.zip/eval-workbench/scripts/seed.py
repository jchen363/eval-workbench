import argparse
import json
from pathlib import Path

from app.db import Database
from app.models import ImportIn
from app.service import Service

ROOT = Path(__file__).resolve().parent.parent


def seed_demo(path):
    db = Database(path)
    with db.connect() as c:
        if c.execute('SELECT count(*) FROM tasks').fetchone()[0]:
            return 0
    data = ImportIn.model_validate_json((ROOT/'data/demo.json').read_text())
    return Service(db).import_data(data)['imported']


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='仅在空数据库中导入合成演示数据')
    parser.add_argument('--db',default=str(ROOT/'data/local.sqlite'))
    args = parser.parse_args()
    print(json.dumps({'seeded':seed_demo(args.db),'provenance':'synthetic_demo'},ensure_ascii=False))
