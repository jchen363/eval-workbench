"""Run scripts as python -m scripts.NAME from the repository root."""
