import argparse
import sqlite3
from pathlib import Path


def backup_database(source,destination):
    source,destination = Path(source),Path(destination)
    if not source.is_file():
        raise ValueError('源数据库不存在')
    if destination.exists():
        raise ValueError('目标文件已存在，请选择新的备份路径')
    destination.parent.mkdir(parents=True,exist_ok=True)
    with sqlite3.connect(f'file:{source.resolve()}?mode=ro',uri=True) as src:
        with sqlite3.connect(destination) as dest:
            src.backup(dest)
            if dest.execute('PRAGMA integrity_check').fetchone()[0] != 'ok':
                raise ValueError('备份校验失败')


if __name__ == '__main__':
    p = argparse.ArgumentParser(description='一致性 SQLite 备份（包含历史与复核）')
    p.add_argument('source')
    p.add_argument('destination')
    args = p.parse_args()
    backup_database(args.source,args.destination)
    print('Backup verified: '+args.destination)
