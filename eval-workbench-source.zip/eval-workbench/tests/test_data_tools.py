import sqlite3

from app.db import Database
from app.service import Service
from scripts.seed import seed_demo
from scripts.backup import backup_database


def test_demo_seed_is_explicit_and_idempotent(tmp_path):
    path = tmp_path/'data.sqlite'
    assert seed_demo(path) == 12
    assert seed_demo(path) == 0
    s = Service(Database(path))
    stats = s.stats()
    assert (stats['tasks'],stats['answers'],stats['annotated'],stats['reviewed']) == (12,24,16,0)
    assert stats['human_annotations'] == 0
    assert s.stats(real_only=True)['answers'] == 0


def test_backup_includes_committed_wal_records(tmp_path):
    source = tmp_path/'data.sqlite'
    seed_demo(source)
    destination = tmp_path/'backup.sqlite'
    backup_database(source,destination)
    with sqlite3.connect(destination) as c:
        assert c.execute('PRAGMA integrity_check').fetchone()[0] == 'ok'
        assert c.execute('SELECT count(*) FROM answers').fetchone()[0] == 24


def test_business_error_mid_import_leaves_no_partial_tasks(client):
    payload = {'schema_version':1,'tasks':[
        dict(prompt='可导入',reference='',category='综合',provenance='demo',answers=[]),
        dict(prompt='来源矛盾',reference='',category='综合',provenance='model',answers=[dict(model='A',text='合成回答',source='synthetic_demo')]),
    ]}
    assert client.post('/api/import',json=payload).status_code == 422
    assert client.get('/api/tasks').json()['total'] == 0
