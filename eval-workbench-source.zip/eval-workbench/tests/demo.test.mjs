import {test} from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {DemoAPI} from '../app/static/demo.js';

const fixture=JSON.parse(fs.readFileSync(new URL('../data/demo.json',import.meta.url)));
const memory=()=>{const m=new Map();return {getItem:k=>m.get(k)??null,setItem:(k,v)=>m.set(k,v)}};
const make=()=>new DemoAPI(fixture,memory());
test('demo scores use only current annotations and persist across reload',async()=>{
 const storage=memory(),api=new DemoAPI(fixture,storage);
 const s=await api.request('GET','/api/stats');
 assert.deepEqual([s.tasks,s.answers,s.annotated,s.reviewed,s.human_annotations],[12,24,16,0,0]);
 const first=await api.request('GET','/api/tasks/1');
 const a=first.answers[0];
 const data={...a.annotation,expected_version:a.version,scores:{correctness:1,instruction:1,completeness:1,clarity:1}};
 await api.request('POST',`/api/answers/${a.id}/annotations`,data);
 const reloaded=new DemoAPI(fixture,storage);
 assert.equal((await reloaded.request('GET','/api/tasks/1')).answers[0].annotation.total_score,20);
 assert.equal((await reloaded.request('GET','/api/stats')).annotated,16);
 assert.equal((await reloaded.request('GET',`/api/answers/${a.id}/history`)).length,2);
 await assert.rejects(reloaded.request('POST',`/api/answers/${a.id}/annotations`,data),/修改/);
});
test('demo excludes fixtures and rolls back invalid imports',async()=>{
 const api=make();
 assert.equal((await api.request('GET','/api/tasks',null,{real_only:true})).total,0);
 const invalid={schema_version:1,tasks:[{prompt:'有效',reference:'',category:'综合',provenance:'demo',answers:[]},{prompt:'无效',reference:'',category:'综合',provenance:'model',answers:[{model:'A',text:'x',source:'synthetic_demo'}]}]};
 await assert.rejects(api.request('POST','/api/import',invalid));
 assert.equal((await api.request('GET','/api/tasks')).total,12);
});
test('demo requires distinct review actor and resets approval on revision',async()=>{
 const api=make();const a=(await api.request('GET','/api/tasks/1')).answers[0];
 const path=`/api/answers/${a.id}`;
 await assert.rejects(api.request('POST',path+'/review',{reviewer:a.annotation.annotator,note:'检查',decision:'approved',expected_version:a.version}),/不能相同/);
 await api.request('POST',path+'/review',{reviewer:'复核者',note:'检查通过',decision:'approved',expected_version:a.version});
 assert.equal((await api.request('GET','/api/stats')).reviewed,1);
 await api.request('POST',path+'/annotations',{...a.annotation,expected_version:a.version+1});
 assert.equal((await api.request('GET','/api/stats')).reviewed,0);
});
test('demo rejects blank rationale and fractional scores',async()=>{
 const api=make();const a=(await api.request('GET','/api/tasks/1')).answers[0];
 await assert.rejects(api.request('POST',`/api/answers/${a.id}/annotations`,{...a.annotation,expected_version:a.version,rationale:' '}));
 await assert.rejects(api.request('POST',`/api/answers/${a.id}/annotations`,{...a.annotation,expected_version:a.version,scores:{...a.annotation.scores,correctness:3.5}}));
});
test('export format round trips with explicit append semantics',async()=>{
 const api=make();const exported=await api.request('GET','/api/export',null,{format:'json'});
 await api.request('POST','/api/import',exported);
 assert.equal((await api.request('GET','/api/tasks')).total,24);
 const csv=await api.request('GET','/api/export',null,{format:'csv'});
 assert.ok(csv.startsWith('\ufefftask_id,'));
});
test('two browser tabs reject stale edits instead of losing scores',async()=>{
 const storage=memory(),one=new DemoAPI(fixture,storage),two=new DemoAPI(fixture,storage);
 const a=(await one.request('GET','/api/tasks/1')).answers[0];
 const payload={...a.annotation,expected_version:a.version};
 await one.request('POST',`/api/answers/${a.id}/annotations`,payload);
 await assert.rejects(two.request('POST',`/api/answers/${a.id}/annotations`,payload),/修改/);
});
