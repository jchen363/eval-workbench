import csv
import io

import pytest
from fastapi.testclient import TestClient

from app.main import create_app


@pytest.fixture
def client(tmp_path):
    with TestClient(create_app(tmp_path / 'eval.sqlite')) as c:
        yield c


def task(client, **overrides):
    payload = dict(prompt='计算 17 × 23，只输出整数。', reference='391', category='数学', provenance='demo')
    payload.update(overrides)
    r = client.post('/api/tasks', json=payload)
    assert r.status_code == 201, r.text
    return r.json()


def answer(client, task_id, **overrides):
    payload = dict(model='候选 A', text='391', source='synthetic_demo')
    payload.update(overrides)
    r = client.post(f'/api/tasks/{task_id}/answers', json=payload)
    assert r.status_code == 201, r.text
    return r.json()


def annotation(**overrides):
    payload = dict(scores=dict(correctness=5, instruction=4, completeness=3, clarity=2),
                   rationale='答案正确，但未覆盖全部参考要点，表达有冗余。', error_types=['遗漏要点'],
                   annotator='标注员 A', expected_version=0, annotation_source='ai_assisted')
    payload.update(overrides)
    return payload


def test_persists_and_searches_parameterized_queries(client):
    t = task(client, prompt="O'Reilly 的 SQL 示例是什么？")
    a = answer(client, t['id'])
    assert client.get('/api/tasks', params={'q': "O'Reilly"}).json()['total'] == 1
    assert client.get('/api/tasks', params={'q': "' OR 1=1 --"}).json()['total'] == 0
    assert client.get(f"/api/tasks/{t['id']}").json()['answers'][0]['id'] == a['id']
    assert client.get('/api/tasks', params={'limit': 0}).status_code == 422


def test_sqlite_survives_new_app_instance(tmp_path):
    path = tmp_path / 'persistent.sqlite'
    with TestClient(create_app(path)) as c:
        task(c)
    with TestClient(create_app(path)) as c:
        assert c.get('/api/tasks').json()['total'] == 1


def test_weighted_scoring_and_history_are_atomic(client):
    t = task(client)
    a = answer(client, t['id'])
    url = f"/api/answers/{a['id']}/annotations"
    first = client.post(url, json=annotation())
    assert first.status_code == 200, first.text
    assert first.json()['total_score'] == 80.0
    assert first.json()['version'] == 1
    assert client.post(url, json=annotation()).status_code == 409
    second = client.post(url, json=annotation(expected_version=1, scores=dict(correctness=1,instruction=1,completeness=1,clarity=1)))
    assert second.json()['total_score'] == 20
    history = client.get(f"/api/answers/{a['id']}/history").json()
    assert len(history) == 2
    assert history[0]['snapshot']['total_score'] == 80
    stats = client.get('/api/stats').json()
    assert stats['annotated'] == 1
    assert stats['average_score'] == 20


@pytest.mark.parametrize('patch', [
    {'rationale': '  '}, {'error_types': []}, {'error_types': ['随便编的类别']},
    {'error_types': ['无', '事实错误']}, {'scores': dict(correctness=6,instruction=5,completeness=5,clarity=5)},
    {'scores': dict(correctness=True,instruction=5,completeness=5,clarity=5)},
    {'scores': dict(correctness=4.5,instruction=5,completeness=5,clarity=5)},
    {'annotator': ''}, {'expected_version': -1},
])
def test_rejects_invalid_annotations_without_partial_writes(client, patch):
    a = answer(client, task(client)['id'])
    assert client.post(f"/api/answers/{a['id']}/annotations", json=annotation(**patch)).status_code == 422
    assert client.get(f"/api/answers/{a['id']}/history").json() == []


def test_review_requires_distinct_person_and_current_version(client):
    t = task(client)
    a = answer(client, t['id'])
    base = f"/api/answers/{a['id']}"
    client.post(base + '/annotations', json=annotation())
    payload = dict(decision='approved', reviewer='标注员 A', note='已检查参考答案。', expected_version=1)
    assert client.post(base + '/review', json=payload).status_code == 422
    payload['reviewer'] = '复核员 B'
    payload['expected_version'] = 0
    assert client.post(base + '/review', json=payload).status_code == 409
    payload['expected_version'] = 1
    r = client.post(base + '/review', json=payload)
    assert r.status_code == 200, r.text
    assert r.json()['status'] == 'approved'
    assert r.json()['version'] == 2
    assert client.get('/api/stats').json()['reviewed'] == 1
    # A revision invalidates earlier approval, while preserving the review audit entry.
    r = client.post(base + '/annotations', json=annotation(expected_version=2))
    assert r.json()['status'] == 'submitted'
    assert r.json()['reviewer'] is None
    assert len(client.get(base + '/history').json()) == 3


def test_review_unannotated_answer_returns_useful_error(client):
    a = answer(client, task(client)['id'])
    r = client.post(f"/api/answers/{a['id']}/review", json=dict(decision='approved',reviewer='B',note='复核',expected_version=0))
    assert r.status_code == 422


def test_import_rolls_back_and_export_round_trips(client):
    payload = {'schema_version': 1, 'tasks': [
        dict(prompt='任务一', reference='参考', category='综合', provenance='demo', answers=[dict(model='A', text='答案', source='synthetic_demo')]),
        dict(prompt='任务二', reference='参考', category='综合', provenance='demo', answers=[dict(model='', text='答案', source='synthetic_demo')]),
    ]}
    assert client.post('/api/import', json=payload).status_code == 422
    assert client.get('/api/tasks').json()['total'] == 0
    payload['tasks'][1]['answers'][0]['model'] = 'B'
    assert client.post('/api/import', json=payload).json()['imported'] == 2
    exported = client.get('/api/export', params={'format': 'json'}).json()
    assert exported['schema_version'] == 1
    assert len(exported['tasks']) == 2
    assert client.post('/api/import', json=exported).status_code == 200
    assert client.get('/api/tasks').json()['total'] == 4  # Import intentionally appends; backups use SQLite backup.


def test_import_annotations_preserves_source(client):
    ann = annotation()
    ann.pop('expected_version')
    payload = dict(schema_version=1,tasks=[dict(prompt='测试',reference='参考',category='综合',provenance='model',
        answers=[dict(model='声明的模型',text='回答',source='model_output',annotation=ann)])])
    assert client.post('/api/import',json=payload).status_code == 200
    data = client.get('/api/export',params={'format':'json'}).json()
    assert data['tasks'][0]['answers'][0]['annotation']['annotation_source'] == 'ai_assisted'


def test_archive_filters_real_data_and_keeps_history(client):
    d = task(client)
    real = task(client, provenance='model')
    answer(client, real['id'], source='model_output')
    assert client.get('/api/tasks',params={'real_only': True}).json()['total'] == 1
    assert client.get('/api/stats',params={'real_only': True}).json()['tasks'] == 1
    assert client.post(f"/api/tasks/{d['id']}/archive").status_code == 200
    assert client.get('/api/tasks').json()['total'] == 1
    assert client.get(f"/api/tasks/{d['id']}").json()['archived'] is True
    assert client.post(f"/api/tasks/{d['id']}/answers",json=dict(model='x',text='x',source='synthetic_demo')).status_code == 409


def test_exports_are_safe_for_spreadsheets(client):
    t = task(client,prompt='=1+1')
    answer(client,t['id'],text='+SUM(A1:A2)')
    r = client.get('/api/export',params={'format':'csv'})
    rows = list(csv.DictReader(io.StringIO(r.text.lstrip('\ufeff'))))
    assert rows[0]['prompt'] == "'=1+1"
    assert rows[0]['answer'] == "'+SUM(A1:A2)"
    assert client.get('/api/export',params={'format':'csv','q':'不存在'}).text.lstrip('\ufeff').startswith('task_id,')


def test_missing_resource_and_blank_task(client):
    assert client.get('/api/tasks/999').status_code == 404
    assert client.post('/api/tasks',json=dict(prompt=' ',reference='',category='综合',provenance='demo')).status_code == 422


def test_feedback_lifecycle(client):
    r = client.post('/api/feedback',json=dict(content='评分说明需要更清晰。',reporter='试用者'))
    assert r.status_code == 201
    fid = r.json()['id']
    assert client.get('/api/feedback').json()[0]['status'] == 'open'
    assert client.put(f'/api/feedback/{fid}',json=dict(status='resolved',resolution='补充评分锚点。')).status_code == 200
    assert client.get('/api/feedback').json()[0]['resolution'] == '补充评分锚点。'


def test_optional_access_token_protects_data(tmp_path):
    with TestClient(create_app(tmp_path / 'secured.sqlite', token='test-secret-token')) as c:
        assert c.get('/').status_code == 200
        assert c.get('/health').status_code == 200
        assert c.get('/api/tasks').status_code == 401
        assert c.post('/api/tasks',json={}).status_code == 401
        assert c.get('/api/tasks',headers={'Authorization':'Bearer test-secret-token'}).status_code == 200


def test_category_and_status_filter_denominators(client):
    t = task(client)
    a = answer(client,t['id'])
    answer(client,t['id'],model='B')
    client.post(f"/api/answers/{a['id']}/annotations",json=annotation())
    s = client.get('/api/stats').json()
    assert (s['answers'],s['annotated'],s['pending']) == (2,1,1)
    assert client.get('/api/tasks',params={'status':'pending'}).json()['total'] == 1
    assert client.get('/api/tasks',params={'status':'submitted'}).json()['total'] == 1
    assert client.get('/api/tasks',params={'category':'不存在'}).json()['total'] == 0

def test_ephemeral_hosting_discloses_temporary_storage(tmp_path):
    with TestClient(create_app(tmp_path / 'free.sqlite',ephemeral=True)) as c:
        meta = c.get('/api/meta').json()
        assert meta['ephemeral'] is True
        assert '临时' in meta['storage']
